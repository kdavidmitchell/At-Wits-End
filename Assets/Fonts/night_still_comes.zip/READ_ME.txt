Hi there!

Thank you so much for downloading this font sample. I really appreciate your interest and hope you enjoy using it! 

Also, if you like this sample, please consider purchasing the entire font (and perhaps other fonts) at my website: http://crosscountrysnow.wix.com/fonts#!fonts/c1k7w
The complete fonts contain over 550 glyphs each, with features such as:
	-> Small caps, 
	-> Several ligatures, 
	-> Subscript and superscript numbers and letters, 
	-> Lining and old style numbers (proportional and tabular),
	-> Fractions.

Best wishes,
-Ana